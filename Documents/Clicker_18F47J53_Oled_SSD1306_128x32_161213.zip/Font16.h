typedef unsigned char BYTE;
typedef unsigned short WORD;

typedef unsigned int DWORD;

#define nr_chrs 112
#define chr_hgt 16
#define data_size 8
#define firstchr 32

extern const BYTE widtbl[112];
extern const BYTE * chrtbl[112];
