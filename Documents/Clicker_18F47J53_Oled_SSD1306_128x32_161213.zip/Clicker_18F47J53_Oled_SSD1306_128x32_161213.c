

// https://github.com/ExploreEmbedded/8051_DevelopmentBoard/blob/master/Code/Keil_Sample_Codes/13a-OledDisplayStrings/oled_i2c.lst


/************************************************************************************
*  Copyright (c), 2014, HelTec Automatic Technology co.,LTD.
*            All rights reserved.
* Http:    www.heltec.cn
* Email:   cn.heltec@gmail.com
* WebShop: heltec.taobao.com
* File name: main.c
* Project  : HelTec.uvprij
* Processor: STM32F103C8T6
* Compiler : MDK fo ARM
* Author : С��
* Version: 1.00
* Date   : 2014.4.8
* Email  : hello14blog@gmail.com
* Adaptation pour PIC18F47J53 par PF ..rev 02-12-2016
************************************************************************************
*/


#define Version "161213"
 // rajout  big numbers

#include "OLED_I2C_161213.h"
    // problem here !
    // Ok at the 1rst pass    in while(1) loop
    // BAD at the second pass .. timer0 never Elapsed .. even Keyboard detection is still ok
    // but is allways OK if i display only 3 chinese char  instead of 4
    // PB du au delay de 4x1000mS ?
    // => rajout RAZ TMR0IF dans init timer0    => OK avec 4 car chinese !!


 #define Project "Clicker_18F47J53_Oled_SSD1306_1612.mcppi"
 #define Source   "Clicker_18F47J53_Oled_SSD1306_128x32_"
 #define OSCILLATEUR_INTERNE
 #define BYTE unsigned char
 
 // #define Version "161212"
 // PB avec timer0 ??  manquait le RAZ de TMR0IF dans l'init timer0
 
//  #define Version "161210"
 // tempo de 6 sec  ou appui clavier entre les differents test d'affichage
 // 2em page de 128x32 pixel ???
 
  //ac:Oled_photo

#define PROCESSOR 18F47J53
#define POWER_SUPPLY_3_3V

#ifdef OSCILLATEUR_INTERNE
#define FOSC 8.0  // MHz
//18F47J53_Fosc_Interne_8MHz.cfgsch
#else
#define FOSC 16.0  // MHz
#endif

#define CLS 12
#define CR 13
#define LF 10
#define TAB 9
#define BACK 8
#define Separator 0x20   // space


#define With_UART2
#ifdef With_UART2
// redinition pour garder les memes habitudes !
#define UART2_Write UART_Remappable_Write
#define UART2_Write_Text UART_Remappable_Write_Text
#define UART2_Read  UART_Remappable_Read
#define UART2_Init UART_Remappable_Init
#define UART2_Tx_Idle  UART_Remappable_Tx_Idle
#endif

 #define Punkt 0
#define Fleche_Down 1
#define Fleche_Up 2

extern  unsigned char code F8X16[];
extern const unsigned char * Big_Numbers[] ;
extern void Big_affichage( unsigned char posX,unsigned char N);
extern void Affiche_Car_8x8 ( unsigned char posX, unsigned char PosY,unsigned char N );

// -- Click 18F47J53 Hardware definitions ----------

// RD0 = SCL I2C2   ------ OLED SCL SSD1306
// RD1 = SCA I2C2   ------ OLED SDA SSD1306

sbit LD1 at LATA0_bit;        // led + 4,7K !
sbit LD2 at LATA1_bit;        // led + 4,7K !
sbit LD1_Direction at TRISA0_bit;
sbit LD2_Direction at TRISA1_bit;

sbit T1 at RD3_bit;   //  tir� au +5V via 10K
sbit T2 at RD2_bit;   //   tir� au +5V via 10K
sbit T1_Direction at TRISD3_bit;
sbit T2_Direction at TRISD2_bit;
#define BP T1
#define BP1 T1
#define BP2 T2

sbit ANA_RA2 at PORTA.B2;
sbit ANA_RA2_Direction at TRISA2_bit;



extern unsigned char BMP1[];      // 512
extern unsigned char RamBuffer[]; // 512

char TEXTE[128];
char CRam1[17];
char *txt;
unsigned int i,j,k,l;
unsigned char *BMap;

#ifdef With_UART2
#define MAXLEN2 128
volatile unsigned char buffer2[MAXLEN2] ;
volatile unsigned int Index2=0;
volatile unsigned int i2=0;
volatile unsigned int UART2_DataReady=0;
volatile unsigned int Flag_data_OK ;
volatile unsigned char c2=0;
unsigned char *p2;
#endif

//#define OLED_LCD_Adr 0x78   // mini OLED LCD @ I2C
#define OLED_ADDRESS    0x78
unsigned char cx;
unsigned char adresse;


volatile struct chbits {   // 8 flags
     unsigned FrameErr:1;
     unsigned Over:1;
     unsigned Dialogue:1;
     unsigned FLT:1;
     unsigned PPS:1;
     unsigned Sommeil:1;
     unsigned Elapsed_Time:1;
     unsigned Mesure:1;
     unsigned First_Run:1;
   }Drapeaux ;


unsigned char  UART2_Assign_To_PPS(void) ;
void Init_Hardware(void);
void UART2_Write (unsigned char c);
void CRLF2(void);
void UART2_Write_CText(const char *txt);
unsigned char  UART2_Assign_To_PPS(void);
void strConstRamCpy(unsigned char *dest, const code char *source);
void Init_Timer0(void);



void Interrupts() iv 0x0008 ics ICS_AUTO
 {
  if (( TMR0IE_bit==1) && (TMR0IF_bit==1))
  {
  // 6 sec at 8Mhz
  TMR0H         = 0x48;
  TMR0L         = 0xE5;
  Drapeaux.Elapsed_Time =1;
  TMR0IE_bit = 0;
  TMR0IF_bit = 0;
  }

}



/* Hardware init specific for Clicker 18F47J53 */
void Init_Hardware()
{
  ANCON0 = 0xFB;       // Default all pins to digital except AN2 analog
  ANCON1 = 0x1F;
  TRISD=0b00001100;
  PORTE=0;
  LATE=0;
  TRISE.REPU=0;   // 0 = All PORTE pull-ups are disabled     1 = PORTE pull-ups are enabled for any
//  DS18B20_Direction=1;
  //PCFG<7:0>: Analog Port Configuration bits (AN7-AN0)
  //  1 = Pin configured as a digital port
  // 0 = Pin configured as an analog channel � digital input disabled and reads �0�
  ANA_RA2_Direction=1;
  CM1CON=0x07;
  // hardware sur la carte Click
  T1_Direction = 1;         // Set direction for buttons
  T2_Direction = 1;
  LD1_Direction = 0;        // Set direction for LEDS
  LD2_Direction = 0;
}

void RAZ_UART2()
{
      RC2IE_bit=0 ;
      for (i2=0;i2<MAXLEN2;i2++) buffer2[i2]=0;
      Index2=0;
     // i2=0;
      c2=RCREG2;
      c2=0;
      UART2_DataReady=0;
      Flag_data_OK=0;
      RC2IE_bit=1 ;
}

 // --- Copie le texte depuis ROM vers RAM
void strConstRamCpy(char *dest, const char *source)
{
  while(*source) *(dest++) = *(source++) ;
  *dest = 0 ;    // terminateur
}


void CRLF2()
{
 UART2_Write(CR);
 UART2_Write(LF);
}

void UART2_Write_CText(const char *t)
{
  while (*t)
  {
   //while (TXSTA2.TRMT == 0);
   // UART2_Write(*txt++);
   if (UART_Remappable_Tx_Idle() == 1)
   {
    UART_Remappable_Write(*t);
    t++;
   }
  }
}

unsigned char UART2_Assign_To_PPS(void)
{
// Mapping I/O pour UART2  sur RD7 et RD6
// rp_num: Remappable pin number. Consult the appropriate datasheet for adequate values.
// input_output: Sets requested pin to be used as an input or output.
// funct_name: Selects internal MCU module for usage.
// return :
// 0 - if peripheral pin mapping wasn't successful.
// 255 - if peripheral pin mapping was successful.
unsigned char T,T1;
T1=0;
T=0;
Unlock_IOLOCK();
T=PPS_Mapping_NoLock(22, _INPUT, _RX2_DT2); // Set pin 22 to  maps RX2/DT2 Input
if (T==255)T1++;
T=PPS_Mapping_NoLock(23, _OUTPUT, _TX2_CK2);// Set pin 23 to  EUSART2 Async TX output
if(T==255) T1++;
Lock_IOLOCK();
return (T1);
}


unsigned char check_device(unsigned char dev_address)
{
char Etat=1;
char Sortie[9];
//  ATTention si un seul Device .. presence pull up resistances indispensables !
// ATTEntion au choix de bus I2C 1 ou 2
// Attention au choix I2C Hardw ou Softw
UART2_Write_CText("Check Device @ ");
ByteToStr(dev_address,Sortie);
UART2_Write_Text(Sortie);
UART2_Write_CText(" on I2C");
UART2_Write_CText("2  HARDW");
I2C2_Start();
Etat= I2C2_Wr(dev_address);
if(Etat!=0 )
 {
  UART2_Write_CText(" is not found");
  Etat=0;
 }
 else
 {
  UART2_Write_CText(" found OK");
  Etat=1;
  }
 I2C2_Stop();
 CRLF2();
 return Etat;
}


void Wait_Keypressed_Or_Timeout(void)
{ char cx;
 //cx=RCREG2;
 cx= UART_Remappable_Read();
 Init_Timer0();
 UART2_Write_CText("\r\nKeyboard Touch ou wait Timeout 3 sec\r\n");
  while((UART_Remappable_Data_Ready() == 0) && (Drapeaux.Elapsed_Time==0));
 cx= UART_Remappable_Read();
 //while((RC2IF_bit==0)&& (Drapeaux.Elapsed_Time==0));
  CRLF2();
}



void Wait_Keypressed(void)
{
char cx;
 //cx=RCREG2;
 cx= UART_Remappable_Read();
 UART2_Write_CText("\r\nAppuyer sur une touche clavier \r\n");
  while(UART_Remappable_Data_Ready() == 0);
 cx= UART_Remappable_Read();
// while(RC2IF_bit==0);
  CRLF2();
}

//Timer0    avec FOSC=8Mhz
//Prescaler 1:256; TMR0 Preload = 18661; Actual Interrupt Time : 6 s
//Place/Copy this part in declaration section
//  T0CON :  TMR0ON T08BIT T0CS T0SE PSA T0PS2 T0PS1 T0PS0    page 207
//  TMR0ON=1     T08BIT=0=> mode 16bits  T0CS=0 internal instruc cycle   T0SE=0
//  PSA=0 =Timer Precaler assigned to Timer0   TOPS<2:0>=111 => 1/256
//  T0CON         = 0x87;
//  TMR0H         = 0x48;
//  TMR0L         = 0xE5;


void Init_Timer0()
{
//Timer0
//Prescaler 1:128; TMR0 Preload = 18661; Actual Interrupt Time : 3 s
//at 8MHz
  T0CON	 = 0x86;
  TMR0H	 = 0x48;
  TMR0L	 = 0xE5;
  Drapeaux.Elapsed_Time =0;
  IPEN_bit=1; //high level interrupt
  TMR0IF_bit=0;
  TMR0IE_bit = 1;
}


void  main(void)
{

  #ifdef OSCILLATEUR_INTERNE
 //18F47J53_Data_Sheet_39964B.pdf  -page 43
 // IRCF<2:0>: Internal Oscillator Frequency Select bits
 //FOSC=8MHz
  OSCCON.B6=1;
  OSCCON.B5=1;
  OSCCON.B4=1;
//bit 3 OSTS: Oscillator Start-up Time-out Status bit  Read Only  1=primary oscillator is running
//bit 2 FLTS: Frequency Lock Tuning Status bit   Read Only   0= not stable
// SCS<1:0>: System Clock Select bits
//11= Postscaled internal clock (INTRC/INTOSC derived)
  OSCCON.B1=1;
  OSCCON.B0=1;
  OSCTUNE.B7=1;  // 31KHz from 8MHz INTOSC
  OSCTUNE.PLLEN=0; // bit 6 disable PLL
  while (OSCCON.FLTS== 0) ; // 0=Not Stable
 #endif

  Init_Hardware();
  LD1=0;
  LD2=0;
  BMap=&BMP1[0];
  txt=&TEXTE[0];
  cx= UART2_Assign_To_PPS() ;
  if (cx==2) Drapeaux.PPS=1; else Drapeaux.PPS=0;
  UART2_Init(19200);
  RC2IE_bit=0;
  GIE_bit         = 1;
  Delay_ms(200);
  UART2_Write(CLS);
  Delay_ms(500);
  /*
  k=164;
  cx=(k==64)?0x12:0x02;
  UART2_Write_CText("cx=");
  ByteToHex(cx,CRam1);
  UART2_Write_Text(CRam1);
  CRLF2();
   Delay_ms(3000);
  */
  UART2_Write_CText("Projet:"Project"\r\n");
  UART2_Write_CText("Source : "Source"_"Version".c\r\n");
  UART2_Write_CText("OLED SCL SSD1306 :\r\n");
  UART2_Write_CText(" RD0 --> I2C2 -> SCL OLED\r\n");
  UART2_Write_CText(" RD1 --> I2C2 -->SDA OLED \r\n");
  UART2_Write_CText("ou 4 lignes de 20 cars 6x8p \r\n");
  CRLF2();
   //Clock Cycle Time mini=2,5�S
  UART2_Write_CText("I2C2 init at 400Khz\r\n");
  I2C2_Init(400000);
  while(I2C2_Is_Idle()==0);
  Delay_ms(100);

  k= check_device(OLED_ADDRESS);
  if(k==0)
     {
      UART2_Write_CText("OLED LCD Non trouv� \r\n");
      LD2=1;
      LD1=0;
     }
  else
 {
  UART2_Write_CText("OLED init\r\n");
 
    OLED_Init();    // <-- test� OK
  // Adafruit Init sequence for 128x64 OLED module
  // Init_OLED();   // BAD !!
  
  
  Delay_ms(1000);
   UART2_Write_CText("OLED ON\r\n");
   OLED_ON();
   Delay_ms(1000);

   while(1)
   {
    txt=&TEXTE[0];
   OLED_CLS();
   Delay_ms(1000);
   UART2_Write_CText("Test OLED Fill avec FF\r\n");
   OLED_Fill(0xFF);
    UART2_Write_CText("OLED CLS\r\n");
    Delay_ms(2500);
    
    OLED_CLS();
    strConstRamCpy(txt, "BIG NUMBERS 0123456  ");
    OLED_ShowStr(0,0,txt,1);
    UART2_Write_Text(txt);CRLF2();
    UART2_Write_CText("OLED Test big Affichage de 0 � 6 : \r\n");
    for (i=0;i<7;i++)
    {
      UART2_Write_CText("OLED big Affichage ");
      UART2_Write(i+48); UART2_Write_CText(" en x=");
      k=i*16;
      WordToStr(k,CRam1);
      UART2_Write_Text(CRam1);
      CRLF2();
      Big_affichage(k,i);
      Delay_ms(1000);
    }
    Wait_Keypressed_Or_Timeout();
    

     OLED_CLS();          // 123456789012345678901
      strConstRamCpy(txt, "Point F.Down F.UP   ");
    OLED_ShowStr(0,0,txt,1);
    UART2_Write_Text(txt);CRLF2();
     Affiche_Car_8x8 ( 8,1,Punkt);
     Affiche_Car_8x8 ( 16,1,Fleche_Down);
     Affiche_Car_8x8 ( 32,1,Fleche_Up);
      Wait_Keypressed_Or_Timeout();

    OLED_CLS();        // 123456789012345678901
    strConstRamCpy(txt,  "  Chinese Chars      ");
    OLED_ShowStr(0,0,txt,1);
    for(i=0;i<4;i++)
    {
        UART2_Write_CText("OLED Show Chinese Car #");
        UART2_Write(i+48);
        CRLF2();
       OLED_ShowCN(i*20,1,i);
       Delay_ms(250);
    }
     Wait_Keypressed_Or_Timeout();
   
   Strap1:
   
   /*    A suivre
     OLED_CLS();
     UART2_Write_CText("OLED Show unsigned char code F8X16[]\r\n");
     for(i=0;i<9;i++)
    {
        UART2_Write_CText("\r\nOLED code F8X16[] Car #");
        UART2_Write(i+48);
        CRLF2();
        for (j=0;j<16;j++)
        {
        c2=F8X16[i*16+j];
       // Decompile_byte(c2);
       // CRLF2();
        Delay_ms(100);
        } 
      }
      Wait_Keypressed_Or_Timeout();

    OLED_CLS();
   //ShowBigNumber(unsigned char x,unsigned char  y, unsigned char N)  /
    for(i=0;i<3;i++)
    {
        UART2_Write_CText("OLED Show BIG number Car #");
        UART2_Write(i+48);
        CRLF2();
       ShowBigNumber(i*24,1,i);
       Delay_ms(1000);
    }
     Wait_Keypressed_Or_Timeout();
   
  goto Strap2 ;
     */
     
     
     UART2_Write_CText("OLED CLS\n");
     OLED_CLS();
     UART2_Write_CText("Ecriture en page 0 � 3 \r\n");
     UART2_Write_CText ("ShowStr Matrice 6x8 \r\n");
     strConstRamCpy(txt,"4 L de 21 carac. 6x8 ");
    UART2_Write_Text(txt);CRLF2();
    OLED_ShowStr(0,0,txt,1);
    strConstRamCpy(txt, "123456789012345678901");
    UART2_Write_Text(txt);CRLF2();
    OLED_ShowStr(0,1,txt,1);
     strConstRamCpy(txt,"paulfjujo@free.fr2016");
    UART2_Write_Text(txt);CRLF2();
    OLED_ShowStr(0,2,txt,1);
     strConstRamCpy(txt,"Using MikroC pro 6.63");
    UART2_Write_Text(txt);CRLF2();
    OLED_ShowStr(0,3,txt,1);
    
      Wait_Keypressed_Or_Timeout();
    
    UART2_Write_CText("Ecriture en page 4 a 7 \r\n");
    strConstRamCpy(txt  ,"Ecriture pages 4 a 7 ");
    UART2_Write_Text(txt);CRLF2();
    OLED_ShowStr(0,4,txt,1);
      strConstRamCpy(txt,"Ecriture en page 5   ");
    UART2_Write_Text(txt);CRLF2();
    OLED_ShowStr(0,5,txt,1);
      strConstRamCpy(txt,"Ecriture en page 6   ");
    UART2_Write_Text(txt);CRLF2();
    OLED_ShowStr(0,6,txt,1);
      strConstRamCpy(txt,"Ecriture en page 7   ");
    UART2_Write_Text(txt);CRLF2();
    OLED_ShowStr(0,7,txt,1);
    Wait_Keypressed_Or_Timeout();

    UART2_Write_CText("Scroll de 4 pages UP =>Affiche pages 4 � 7 \r\n");
    for (i=0;i<32;i++)
    {
       WriteCmd(0xD3); //-set display offset
       WriteCmd(i);
       Delay_ms(50);
    }
     Wait_Keypressed_Or_Timeout();
     
      UART2_Write_CText("Start 0xD3 adresse=0x00 => R�-affiche pages 0 � 3 \r\n");
      WriteCmd(0xD3); //--set start line address 40h =  set   to page 0
      WriteCmd(0x40);  // acces pages 0 � 3
      Wait_Keypressed_Or_Timeout();
      
      UART2_Write_CText("Start adresse0xD3=0x60 => r�-affiche pages 4 � 7\r\n");
      WriteCmd(0xD3); //--set start line address 60h =  set   to  page 4
      WriteCmd(0x60);  // acces pages 4 � 7
      WriteCmd(0xA4);
      Wait_Keypressed_Or_Timeout();

    OLED_CLS();
    UART2_Write_CText("ShowStr Matrice 6x8 \r\n");
    strConstRamCpy(txt,"21 caracteres jaunes ");
    UART2_Write_Text(txt);CRLF2();
    OLED_ShowStr(0,0,txt,1);

    UART2_Write_CText("PAULFJUJO (size2)\r\n");
    strConstRamCpy(txt,"PAULFJUJO");
    OLED_ShowStr(0,1,txt,2);
    UART2_Write_CText("Free.13867 (size2)\r\n");
    strConstRamCpy(txt,"Free.13867");
    OLED_ShowStr(0,3,txt,2);
    Wait_Keypressed_Or_Timeout();
    
    UART2_Write_CText("Scroll de 16 pts vers le haut\r\n");
    for (i=0;i<16;i++)
    {
       WriteCmd(0xD3); //-set display offset
       WriteCmd(i);
       Delay_ms(50);
    }
    Wait_Keypressed_Or_Timeout();

    OLED_Fill(0x02);
    UART2_Write_CText("OLED FILL 0x02\r\n");
    Delay_ms(2500);
    UART2_Write_CText("OLED CLS\n");
    OLED_CLS();
    
    UART2_Write_CText(" Write_Char_At(3+i*..\r\n");
    strConstRamCpy(txt,"PAULFJUJO");
    k=strlen(txt);
    for (i=0;i<k;i++)
    {
     Write_Char_At(i*6,0,*(txt+i));
      Write_Char_At(8+i*6,1,*(txt+i));
        Write_Char_At(16+i*6,2,*(txt+i));
           Write_Char_At(24+i*6,3,*(txt+i));
     Write_Char_At(32+i*6,4,*(txt+i));
      Write_Char_At(40+i*6,5,*(txt+i));
        Write_Char_At(48+i*6,6,*(txt+i));
           Write_Char_At(64+i*6,7,*(txt+i));
     Delay_ms(250);
    }
    Wait_Keypressed_Or_Timeout();
 
    UART2_Write_CText("Start adresse0xD3=0x60 => r�-affiche pages 4 a 7\r\n");
    WriteCmd(0xD3); //--set start line address 60h =  set   to  page 4
    WriteCmd(0x60);  // acces pages 4 � 7
    Wait_Keypressed_Or_Timeout();
    
    Wait_Keypressed_Or_Timeout();
    UART2_Write_CText("Start 0xD3 adresse=0x00 => R�-affiche pages 0 � 3 \r\n");
    WriteCmd(0xD3); //--set start line address 40h =  set   to page 0
    WriteCmd(0x40);  // acces pages 0 � 3
    Wait_Keypressed_Or_Timeout();

    OLED_CLS();
    BMap=&BMP1[0];
    UART2_Write_CText("OLED Draw BitMap BMP1\r\n");
    OLED_DrawBMP(0,0,128,4,BMap);
    Wait_Keypressed_Or_Timeout();

   Strap2:
     OLED_CLS();
     BMap=&RamBuffer[0];
     UART2_Write_CText("OLED Draw BitMap Microchip\r\n");
     OLED_DrawBMP(0,0,128,4,BMap);
     Wait_Keypressed_Or_Timeout();

 } //while
 }//else
}
/*

Projet:Clicker_18F47J53_Oled_SSD1306_1612.mcppi
Source : Clicker_18F47J53_Oled_SSD1306_128x32__161213.c
OLED SCL SSD1306 :
 RD0 --> I2C2 -> SCL OLED
 RD1 --> I2C2 -->SDA OLED
ou 4 lignes de 20 cars 6x8p

I2C2 init at 400Khz
Check Device @ 120 on I2C2  HARDW found OK
OLED init
OLED ON
Test OLED Fill avec FF
OLED CLS
BIG NUMBERS 0123456
OLED Test big Affichage de 0 � 6 :
OLED big Affichage 0 en x=    0
OLED big Affichage 1 en x=   16
OLED big Affichage 2 en x=   32
OLED big Affichage 3 en x=   48
OLED big Affichage 4 en x=   64
OLED big Affichage 5 en x=   80
OLED big Affichage 6 en x=   96

Keyboard Touch ou wait Timeout 4sec

Point F.Down F.UP

Keyboard Touch ou wait Timeout 4sec

OLED Show Chinese Car #0
OLED Show Chinese Car #1
OLED Show Chinese Car #2
OLED Show Chinese Car #3

Keyboard Touch ou wait Timeout 4sec

OLED CLS
Ecriture en page 0 � 3
ShowStr Matrice 6x8
4 L de 21 carac. 6x8
123456789012345678901
paulfjujo@free.fr2016
Using MikroC pro 6.63

Keyboard Touch ou wait Timeout 4sec

Ecriture en page 4 � 7
Ecriture pages 4 � 7
Ecriture en page 5
Ecriture en page 6
Ecriture en page 7

Keyboard Touch ou wait Timeout 4sec

Scroll de 4 pages UP =>Affiche pages 4 � 7

Keyboard Touch ou wait Timeout 4sec

Start 0xD3 adresse=0x00 => R�-affiche pages 0 � 3

Keyboard Touch ou wait Timeout 4sec

Start adresse0xD3=0x60 => r�-affiche pages 4 � 7

Keyboard Touch ou wait Timeout 4sec

ShowStr Matrice 6x8
21 caracteres jaunes
PAULFJUJO (size2)
Free.13867 (size2)

Keyboard Touch ou wait Timeout 4sec

Scroll de 16 pts vers le haut

Keyboard Touch ou wait Timeout 4sec

OLED FILL 0x02
OLED CLS
 Write_Char_At(3+i*..

Keyboard Touch ou wait Timeout 4sec

Start adresse0xD3=0x60 => r�-affiche pages 4 a 7

Keyboard Touch ou wait Timeout 4sec


Keyboard Touch ou wait Timeout 4sec

Start 0xD3 adresse=0x00 => R�-affiche pages 0 � 3

Keyboard Touch ou wait Timeout 4sec

OLED Draw BitMap BMP1

Keyboard Touch ou wait Timeout 4sec

OLED Draw BitMap Microchip

Keyboard Touch ou wait Timeout 4sec

Test OLED Fill avec FF
OLED CLS
BIG NUMBERS 0123456
OLED Test big Affichage de 0 � 6 :
OLED big Affichage 0 en x=    0
OLED big Affichage 1 en x=   16
OLED big Affichage 2 en x=   32
OLED big Affichage 3 en x=   48
OLED big Affichage 4 en x=   64
OLED big Affichage 5 en x=   80
OLED big Affichage 6 en x=   96

Keyboard Touch ou wait Timeout 4sec

Point F.Down F.UP

Keyboard Touch ou wait Timeout 4sec

OLED Show Chinese Car #0
OLED Show Chinese Car #1
OLED Show Chinese Car #2
OLED Show Chinese Car #3

Keyboard Touch ou wait Timeout 4sec

OLED CLS
Ecriture en page 0 � 3
ShowStr Matrice 6x8
4 L de 21 carac. 6x8
123456789012345678901
paulfjujo@free.fr2016
Using MikroC pro 6.63

Keyboard Touch ou wait Timeout 4sec

Ecriture en page 4 � 7
Ecriture pages 4 � 7
Ecriture en page 5
Ecriture en page 6
Ecriture en page 7

Keyboard Touch ou wait Timeout 4sec

Scroll de 4 pages UP =>Affiche pages 4 � 7

Keyboard Touch ou wait Timeout 4sec

Start 0xD3 adresse=0x00 => R�-affiche pages 0 � 3

Keyboard Touch ou wait Timeout 4sec

Start adresse0xD3=0x60 => r�-affiche pages 4 � 7

Keyboard Touch ou wait Timeout 4sec

ShowStr Matrice 6x8
21 caracteres jaunes
PAULFJUJO (size2)
Free.13867 (size2)

Keyboard Touch ou wait Timeout 4sec

Scroll de 16 pts vers le haut

Keyboard Touch ou wait Timeout 4sec

OLED FILL 0x02
OLED CLS
 Write_Char_At(3+i*..

Keyboard Touch ou wait Timeout 4sec

Start adresse0xD3=0x60 => r�-affiche pages 4 a 7

Keyboard Touch ou wait Timeout 4sec


Keyboard Touch ou wait Timeout 4sec

Start 0xD3 adresse=0x00 => R�-affiche pages 0 � 3

Keyboard Touch ou wait Timeout 4sec

OLED Draw BitMap BMP1

Keyboard Touch ou wait Timeout 4sec

OLED Draw BitMap Microchip

Keyboard Touch ou wait Timeout 4sec

Test OLED Fill avec FF

 *********************************************************
 0 1 mikroCPIC1618.exe -MSF -DBG -pP18F47J53 -RA -C -O11111014 -fo8 -N"C:\_MikroC\_MesProjets_MikroC\_18F47J53_Mini_Oled_I2C_LCD\Clicker_18F47J53_Oled_SSD1306_1612.mcppi" -SP"C:\_MikroC\mikroC PRO for PIC\Defs\" -SP"C:\_MikroC\mikroC PRO for PIC\uses\P18\" -SP"C:\_MikroC\_MesProjets_MikroC\_18F47J53_Mini_Oled_I2C_LCD\" -IP"C:\_MikroC\_MesProjets_MikroC\_18F47J53_Mini_Oled_I2C_LCD\" "OLED_I2C2_161213.c" "Clicker_18F47J53_Oled_SSD1306_128x32_161213.c" "__Lib_Math.mcl" "__Lib_MathDouble.mcl" "__Lib_System.mcl" "__Lib_Delays.mcl" "__Lib_CType.mcl" "__Lib_CString.mcl" "__Lib_CStdlib.mcl" "__Lib_Conversions.mcl" "__Lib_I2C_b45d01.mcl" "__Lib_UART_c67.mcl" "__Lib_PPS_4xJ53.mcl" "__Lib_UART_Remappable.mcl"
0 1139 Available RAM: 3739 [bytes], Available ROM: 131064 [bytes]
0 122 Compilation Started P18F47J53.c
3886 123 Compiled Successfully P18F47J53.c
0 122 Compilation Started __Lib_Delays.c
172 123 Compiled Successfully __Lib_Delays.c
0 122 Compilation Started codetab_161213.h
489 1163 Variable 'x1' has been declared, but not used OLED_I2C2_161213.c
538 123 Compiled Successfully OLED_I2C2_161213.c
393 1164 Variable 'y_bit' has been eliminated by optimizer OLED_I2C2_161213.c
437 1164 Variable 'C1' has been eliminated by optimizer OLED_I2C2_161213.c
491 1164 Variable 'Cc' has been eliminated by optimizer OLED_I2C2_161213.c
0 122 Compilation Started oled_i2c_161213.h
0 1004 interrupt handler (Interrupts at 0x0008) Clicker_18F47J53_Oled_SSD1306_128x32_161213.c
372 1509 Generated baud rate is 19231 bps (error = 0.16 percent) Clicker_18F47J53_Oled_SSD1306_128x32_161213.c
636 123 Compiled Successfully Clicker_18F47J53_Oled_SSD1306_128x32_161213.c
249 1164 Variable 'T' has been eliminated by optimizer Clicker_18F47J53_Oled_SSD1306_128x32_161213.c
293 1164 Variable 'cx' has been eliminated by optimizer Clicker_18F47J53_Oled_SSD1306_128x32_161213.c
308 1164 Variable 'cx' has been eliminated by optimizer Clicker_18F47J53_Oled_SSD1306_128x32_161213.c
0 127 All files Compiled in 187 ms
0 1144 Used RAM (bytes): 1770 (47%)  Free RAM (bytes): 1969 (53%) Used RAM (bytes): 1770 (47%)  Free RAM (bytes): 1969 (53%)
0 1144 Used ROM (bytes): 13325 (10%)  Free ROM (bytes): 117739 (90%) Used ROM (bytes): 13325 (10%)  Free ROM (bytes): 117739 (90%)
0 125 Project Linked Successfully Clicker_18F47J53_Oled_SSD1306_1612.mcppi
0 128 Linked in 63 ms
0 129 Project 'Clicker_18F47J53_Oled_SSD1306_1612.mcppi' completed: 454 ms
0 103 Finished successfully: 14 d�c. 2016, 11:34:16 Clicker_18F47J53_Oled_SSD1306_1612.mcppi



*/