/************************************************************************************
*  Copyright (c), 2014, HelTec Automatic Technology co.,LTD.
*            All rights reserved.
* Http:    www.heltec.cn
* Email:   cn.heltec@gmail.com
* WebShop: heltec.taobao.com
* File name: OLED_I2C.c
* Project  : HelTec.uvprij
* Date   : 2014.4.8
* Email  : hello14blog@gmail.com
* Modification: none
* Description:128*64(heltec.taobao.com)SSD1306 IIC
* Function List:
*        1. void I2C_Configuration(void) 
* 2. void I2C_WriteByte(uint8_t addr,uint8_t data) 
* 3. void WriteCmd(unsigned char I2C_Command)
* 4. void WriteDat(unsigned char I2C_Data) 
* 5. void OLED_Init(void) 
* 6. void OLED_SetPos(unsigned char x, unsigned char y) 
* 7. void OLED_Fill(unsigned char fill_Data)
* 8. void OLED_CLS(void) 
* 9. void OLED_ON(void)
* 10. void OLED_OFF(void)
* 11. void OLED_ShowStr(unsigned char x, unsigned char y, unsigned char ch[], unsigned char TextSize)
* 12. void OLED_ShowCN(unsigned char x, unsigned char y, unsigned char N)
* 13. void OLED_DrawBMP(unsigned char x0,unsigned char y0,unsigned char x1,unsigned char y1,unsigned char BMP[]) 
*
* History:
* rev for 18F47J53 by pf
* 05-12-2016
*************************************************************************************/
#include "codetab_161213.h"
#include "OLED_I2C_161213.h"
//#include "Font_Num_Sansserif_16p.h"

#define NBPAGES 8
#define OLED_SETCONTRAST 0x81
#define OLED_DISPLAYALLON_RESUME 0xA4
#define OLED_DISPLAYALLON 0xA5
#define OLED_NORMALDISPLAY 0xA6
#define OLED_INVERTDISPLAY 0xA7
#define OLED_DISPLAYOFF 0xAE
#define OLED_DISPLAYON 0xAF
#define OLED_SETDISPLAYOFFSET 0xD3
#define OLED_SETCOMPINS 0xDA
#define OLED_SETVCOMDETECT 0xDB
#define OLED_SETDISPLAYCLOCKDIV 0xD5
#define OLED_SETPRECHARGE 0xD9
#define OLED_SETMULTIPLEX 0xA8
#define OLED_SETLOWCOLUMN 0x00
#define OLED_SETHIGHCOLUMN 0x10
#define OLED_SETSTARTLINE 0x40
#define OLED_MEMORYMODE 0x20
#define OLED_COLUMNADDR 0x21
#define OLED_PAGEADDR   0x22
#define OLED_COMSCANINC 0xC0
#define OLED_COMSCANDEC 0xC8
#define OLED_SEGREMAP 0xA0
#define OLED_CHARGEPUMP 0x8D


 #define UART2_Write UART_Remappable_Write
 #define UART2_Write_Text UART_Remappable_Write_Text
extern void UART2_Write(unsigned char);
extern void UART2_Write_Text(unsigned char *p);
extern void UART2_Write_CText(const char *txt);
extern void CRLF2(void);
extern void UART2_Write_CText(const char *txt);
extern void Wait_Keypressed(void);

extern unsigned char CRam1[];

void WriteCmd(unsigned char I2C_Command)
{
//   I2C_WriteByte(0x00, I2C_Command);
    I2C2_Start();             //StartI2C();
    I2C2_Wr(OLED_ADDRESS);  //send address
    while( I2C2_Is_Idle()==0);
    I2C2_Wr(0x80);          //send data incomming
     while( I2C2_Is_Idle()==0);
    I2C2_Wr(I2C_Command);       //send command
     while( I2C2_Is_Idle()==0);
    I2C2_Stop();              //StopI2C();
     while( I2C2_Is_Idle()==0);
}


void WriteDat(unsigned char I2C_Data)
{
//   I2C_WriteByte(0x40, I2C_Data);
     I2C2_Start();             //StartI2C();
    I2C2_Wr(OLED_ADDRESS);  //send address
    while( I2C2_Is_Idle()==0);
    I2C2_Wr(0x40);          //send data incomming
  //I2C2_Repeated_Start();
    while( I2C2_Is_Idle()==0);
    I2C2_Wr(I2C_Data);       //send Data
     while( I2C1_Is_Idle()==0);
    I2C2_Stop();              //StopI2C();
    while( I2C2_Is_Idle()==0);
 }


void OLED_Init(void)
{
//SSD1306.pdf
//Software Configuration

       WriteCmd(0xAE); //display off
       Delay_ms(200);
       WriteCmd(0xAF); //display on
       Delay_ms(100);
       WriteCmd(0xB0);// Set GDDRAM Page start adresse [2:0]  0 � 7
       WriteCmd(0x00);   // mini 0
       WriteCmd(0x07);   // maxi

        WriteCmd(0x20); //Set Horizontal Memory Addressing Mode
                       //A[1:0] = 00b, Horizontal Addressing Mode
                       //A[1:0] = 01b, Vertical Addressing Mode
                       //A[1:0] = 10b, Page Addressing Mode (RESET)
                       //A[1:0] = 11b, Invalid
        WriteCmd(0x02); //    Page Addressing Mode (RESET)
      
        WriteCmd(0x21); // Setup column start and end address
         WriteCmd(0);   //A[6:0] : Column start address, range : 0-127d,(RESET=0d)
        WriteCmd(0x7F);  // B[6:0]: Column end address, range : 0-127d,(RESET =127d)

        WriteCmd(0x22);//  Setup page start and end address
                         //  A[2:0] : Page start Address, range : 0-7d,
                         // (RESET = 0d)
                         //  B[2:0] : Page end Address, range : 0-7d,
                         // (RESET = 7d)
        WriteCmd(0x00);
        WriteCmd(0x07);     //was 7

       // WriteCmd(0xA0); //--set segment re-map colum 0 to SEG 0     de droite -> gauche
       WriteCmd(0xA1); //--set segment re-map to 127     de gauche -> droite
     
       WriteCmd(0xA4);//command enable display outputs according to the GDDRAM contents.
     //  WriteCmd(0xA5);//command forces the entire display to be �ON�, regardless of the contents of the display data RAM.

     
       WriteCmd(0xA6);//normal display
     //  WriteCmd(0xA7);//reverse display

       WriteCmd(0xC8); //Set COM Output Scan Direction
       //C0h, X[3]=0b: normal mode (RESET) Scan from COM0 to COM[N �1]
       //C8h, X[3]=1b: remapped mode. Scan from COM[N-1] to COM0
      
        WriteCmd(0xD3); //--set start line address 40h =  set   to 0
        WriteCmd(0x40);  // ou 0x3F
     // was     WriteCmd(0x00);

        //0xD3,0x3F, // DISPLAY offset ROW0 - L0xD3,0x00,leaves one row of pixels at top. 0xD3,0x3F is better

      WriteCmd(0xD5); //--set display clock divide ratio/oscillator frequency
      WriteCmd(0x80); //--set divide ratio   80h
      
       WriteCmd(0xA8); //--set multiplex ratio to 63
       WriteCmd(0x3F); //  was 3F

       WriteCmd(0xD6); //-- This command is to set the vcommon signals padconfiguration.
       WriteCmd(0x80); // --set divide ratio   80h


       WriteCmd(0xD9); //--set display clock divide ratio/oscillator frequency
        // A[3:0] : Phase 1 period of up to 15 DCLK clocks 0 is invalid entry(RESET=2h)
        // A[7:4] : Phase 2 period of up to 15 DCLKclocks 0 is invalid entry(RESET=2h )
       WriteCmd(0x1F); //  22h --reset values   22h
       //  WriteCmd(0x1F); //  44h --reset values   22h

        //0xDA, (C.OLED_HEIGHT==64)?0x12:0x02,
        WriteCmd(0xDA); //--set com pins hardware configuration
        WriteCmd(0x00);  // was 0x02      32
//        WriteCmd(0x12);  // 0x12h   64
        //        A[4]=0b, Sequential COM pin configuration
        //        A[4]=1b(RESET), Alternative COM pin configuration
        //        A[5]=0b(RESET), Disable COM Left/Right remap
        //        A[5]=1b, Enable COM Left/Right remap

    //   WriteCmd(0xE0);      // Read-Modify-Write start
       WriteCmd(0xEE);      // Read-Modify-Write end.
       
       WriteCmd(0x81); //--set contrast control register
       WriteCmd(0x7F); // 0x00~0xff

        WriteCmd(0x2E); // no scrolling

        WriteCmd(0xDB); //--set VComH deselect level
        //   WriteCmd(0x35); //--POR =35h
        WriteCmd(0x40); // 20H => 0.77x Vcc (Reset value)

       WriteCmd(0x8D); //--set DC-DC enable  Charge Pump Setting
       WriteCmd(0x14); // 0x14 Enable Charge Pump
       WriteCmd(0xAF); //--turn on oled panel
}


void Init_OLED(void)      // bad
{

    WriteCmd(OLED_DISPLAYOFF);         // 0xAE
    WriteCmd(OLED_SETDISPLAYCLOCKDIV); // 0xD5
    WriteCmd(0x80);                    // the suggested ratio 0x80
    WriteCmd(OLED_SETMULTIPLEX);       // 0xA8
    WriteCmd(0x1F);
    WriteCmd(OLED_SETDISPLAYOFFSET);   // 0xD3
    WriteCmd(0x0);                        // no offset
    WriteCmd(OLED_SETSTARTLINE | 0x0); // line #0
    WriteCmd(OLED_CHARGEPUMP);         // 0x8D
    WriteCmd(0xAF);
    WriteCmd(OLED_MEMORYMODE);         // 0x20
    WriteCmd(0x00);                    // 0x0 act like ks0108
    WriteCmd(OLED_SEGREMAP | 0x01);
    WriteCmd(OLED_COMSCANDEC);
    WriteCmd(OLED_SETCOMPINS);         // 0xDA
    WriteCmd(0x02);
    WriteCmd(OLED_SETCONTRAST);        // 0x81
    WriteCmd(0x8F);
    WriteCmd(OLED_SETPRECHARGE);       // 0xd9
    WriteCmd(0xF1);
    WriteCmd(OLED_SETVCOMDETECT);      // 0xDB
    WriteCmd(0x40);
    WriteCmd(OLED_DISPLAYALLON_RESUME);// 0xA4
    WriteCmd(OLED_NORMALDISPLAY);      // 0xA6
    WriteCmd(OLED_DISPLAYON);          //--turn on oled panel

}



void OLED_SetPos(unsigned char x, unsigned char y)
{ 
        WriteCmd(0xB0+y);
     //  WriteCmd(((x&0x0f))| 0x01);
       WriteCmd(x&0x0f) ;
       WriteCmd(((x&0xf0)>>4)|0x10);
     //   WriteCmd((x&0xf0)>>4+0x10);

}

void Write_Char_At(unsigned char X,unsigned char Y, unsigned char C)
{ int i;
unsigned char ca;

    if (C>=32)
    {
     ca=C-32;
    OLED_SetPos(X,Y);
    for(i=0;i<6;i++)   WriteDat(font_regular_6x8[ca][i]) ;
    }
}

void OLED_Fill(unsigned char fill_Data)
{
        unsigned char m,n;
        OLED_SetPos(0,0);
        for(m=0;m<NBPAGES;m++)   // was <8
        {
                WriteCmd(0xB0+m);                //page0-page1
                Delay_us(50);
                WriteCmd(0x00);                //low column start address
                WriteCmd(0x10);                //high column start address
                for(n=0;n<128;n++)
               {
                    WriteDat(fill_Data);
                    Delay_us(50);
                }
        }
}

void OLED_CLS(void)
{
     unsigned char m,n;
       WriteCmd(0x21); // Setup column start and end address
       WriteCmd(0);   //A[6:0] : Column start address, range : 0-127d,(RESET=0d)
       WriteCmd(127);  // B[6:0]: Column end address, range : 0-127d,(RESET =127d)
       WriteCmd(0x22);
       WriteCmd(0);
       WriteCmd(7);
       WriteCmd(0xD3); //-set display offset
       WriteCmd(0x40); //page 0 � 3
       OLED_SetPos(0,0);
        for(m=0;m<8;m++)  // was <8
        {
                WriteCmd(0xB0+m);                //page0-page1
                WriteCmd(0x01);                //low column start address
                WriteCmd(0x10);                //high column start address
                for(n=0;n<128;n++)
               {
                    WriteDat(0x00);
                     Delay_us(10);
                }
        }
       WriteCmd(0x2E);
        OLED_SetPos(0,0);
}

void OLED_ON(void)
{
       WriteCmd(0x8D);
        WriteCmd(0x14);
        WriteCmd(0xAF);
}

void OLED_OFF(void)
{
        WriteCmd(0x8D);
        WriteCmd(0x10);
        WriteCmd(0xAE);
}

//--------------------------------------------------------------
// Prototype      : void OLED_ShowChar(unsigned char x, unsigned char y, unsigned char ch[], unsigned char TextSize)
// Parameters     : x,y --(x:0~127, y:0~7); ch[] ; TextSize (1:6*8 ; 2:8*16)
//--------------------------------------------------------------
void OLED_ShowStr(unsigned char x, unsigned char y, unsigned char *ch, unsigned char TextSize)
{
        unsigned char c = 0,i = 0,j = 0,xd=0,yd=0;
        xd=x;
        yd=y;
        if((y%NBPAGES)==0)
        yd = y/NBPAGES;
      else
     yd = y;
        OLED_SetPos(xd,yd);
        switch(TextSize)
        {
                case 1:
                  while(*(ch+j) !=0)
                    {
                     c = *(ch+j) - 32;
                     if(xd > 120)
                     {
                      xd = x;
                      yd=y+1;
                       OLED_SetPos(xd,yd);
                     }
                      for(i=0;i<6;i++)   WriteDat(font_regular_6x8[c][i]) ;
                     xd=xd+6;
                     j++;
                    }
                    break;
                case 2:
                     while(*(ch+j) !=0)
                     {
                      c = *(ch+j) - 32;
                      if(xd > 112)
                      {
                        xd = x;
                        yd=yd+1;
                        }
                      OLED_SetPos(xd,yd);
                      for(i=0;i<8;i++) WriteDat(F8X16[c*16+i]);
                     OLED_SetPos(xd,yd+1);
                     for(i=0;i<8;i++) WriteDat(F8X16[c*16+i+8]);
                      xd=xd+8;
                      j++;
                     }
                      break;
                 default:
                     break  ;
        }
}

//--------------------------------------------------------------
// Prototype      : void OLED_ShowCN(unsigned char x, unsigned char y, unsigned char N)
// Parameters     : x,y --(x:0~127, y:0~7); N:codetab.h
//---------------------------------------------
void OLED_ShowCN(unsigned char x, unsigned char y, unsigned char N)
{
        unsigned char wm=0;
        unsigned int  adder=32*N;
     //   unsigned int  adder=64*N;
        OLED_SetPos(x , y);
        for(wm = 0;wm < 16;wm++)
        {
                WriteDat(Chinese_F16x16[adder]);
                adder=adder + 1;
        }

        OLED_SetPos(x,y + 1);
        for(wm = 0;wm < 16;wm++)
        {
                WriteDat(Chinese_F16x16[adder]);
                adder= adder + 1;
        }
}


void OLED_pixel(short x, short y, char color)
{
    char y_bit = y;
    char x_bit= x/8;
    unsigned int xp  = x%8;
    if (color==1) 
      RamBuffer[x][y]= RamBuffer[x_bit][y] | (1<<xp);
      else
           RamBuffer[x_bit][y]= RamBuffer[x_bit][y] & (1<<xp);
 }
 /*
 void OLED_pixel(LONG x,long y)
{
   LONG nt;
   LONG pagina;
   LONG bit;
   pagina = y /8;
   bit= y-(pagina*8);
   nt= DISPLAY[pagina*128+x];
   nt |= 1 << bit;
   DISPLAY[pagina*128+x] = nt;
}*/
 
void Refresh_OLED(void)
{
    int x,y;
          WriteCmd(0xB0);                //page0-page1
          WriteCmd(0x00);                //low column start address
          WriteCmd(0x10);                //high column start address
          for(x=0;x<128;x++)
           {
           for (y=0;y<32;y++)  WriteDat(RamBuffer[x][y]);
             Delay_us(10);
          }
}



//--------------------------------------------------------------
// Prototype      : void OLED_DrawBMP(unsigned char x0,unsigned char y0,unsigned char x1,unsigned char y1,unsigned char BMP[]);
// Parameters     : x0,y0 --(x0:0~127, y0:0~7); x1,y1 -(x1:1~128,y1:1~8)
//--------------------------------------------------------------
void OLED_DrawBMP(unsigned char x0,unsigned char y0,unsigned char x1,unsigned char y1,unsigned char *BM)
{
        unsigned int j=0;
        unsigned char x,y;
        unsigned char C1;
    //    CRLF2();
    //    UART2_Write_CText("BitMap \r\n");
  //OLED_OFF() ;
  if((y1%NBPAGES)==0)
        y = y1/NBPAGES;
      else
     y = y1/NBPAGES + 1;

   /*
       if((y1%4)==0)
        y = y1/4;
      else
     y = y1/4 + 1;
     */
     for(y=y0;y<y1;y++)
     {
       OLED_SetPos(x0,y);
      for(x=x0;x<x1;x++)
      {
      C1=BM[j++];
       WriteDat(C1);
    //   Decompile_byte(C1);
     }
    // CRLF2();
     }
  //    OLED_ON();
}


 // **************************************************************************************
 
 void Decompile_byte(unsigned char un)
{
 unsigned char masque;
 masque = 0x80;
 while (masque > 0u )
 {
   if (un & masque)
       UART2_Write('1');  //  '1'
    else
       UART2_Write('0');  //  '0'
    masque =masque >>1;
  }
}

 
 //==========================================================//
// Prints a display big number (16x16 bytes) in coordinates X Y,
// being multiples of 16. This means we have 16 COLS (0-15)
  void ShowBigNumber(unsigned char x,unsigned char  y, unsigned char N)  //16x16
  {
    unsigned char x1,v=0;
    unsigned int  adder;
    unsigned char Cc;
     adder=32*N;
      OLED_SetPos(x , y);
      for(v = 0;v < 16;v=v+2)
        {
         Cc=Big_Numer_16x16[adder];
         WriteDat(Cc);
          adder++;
        }
         adder=32*N;
         OLED_SetPos(x , y+1);
        for(v = 1;v < 16;v=v+2)
        {
         Cc=Big_Numer_16x16[adder];
         WriteDat(Cc);
          adder++;
        }

  }


void Big_affichage( unsigned char posX, unsigned char N )
{   int k;
    WriteCmd(0x20);WriteCmd(0x00); // horizontal mode
    WriteCmd(0x21); // On configre la largeur de l'ecran
    // pour forcer, limiter le retournement horizontal   voir DS figure 10.5
    WriteCmd(0+posX);        // Colonne minimum
    WriteCmd(15+posX);        // Colonne MAximum;
    WriteCmd(0x22);
    // positionement vertical entre page 1 et 3    H=16 pixels
    WriteCmd(1);
    WriteCmd(3);
    for(k=0;k<48;k++) WriteDat(*(Big_Numbers[N]+k));
  }
  
void Affiche_Car_8x8 ( unsigned char posX, unsigned char PosY,unsigned char N )
 {   int k;
    WriteCmd(0x20);WriteCmd(0x00); // horizontal mode
    WriteCmd(0x21); // On configre la largeur de l'ecran
    // pour forcer, limiter le retournement horizontal   voir DS figure 10.5
    WriteCmd(0+posX);        // Colonne minimum
    WriteCmd(7+posX);        // Colonne MAximum;
    WriteCmd(0x22);
    // positionement vertical entre page 1 et 3    H=16 pixels
    WriteCmd(PosY);
    WriteCmd(PosY+1);
    for(k=0;k<7;k++) WriteDat(*(Car_Speciaux[N]+k));
  }